# SPSD v4.3 — Handoff Document
## Resume from LLM Step (117/161 pairs done)

---

## Current State

| Step | Status |
|---|---|
| Corpus fetch (327 prompts) | ✓ DONE |
| SPSD distillation (161 distilled) | ✓ DONE |
| LLM calls | ⚡ IN PROGRESS — 117/161 done, 44 remaining |
| Cosine similarity scoring | ✗ NOT STARTED |
| LLM-as-judge scoring | ✗ NOT STARTED |
| Hypothesis tests + Excel report | ✗ NOT STARTED |

---

## What You Need

### Files from the person handing this over (3 data files):
```
spsd_results_v3.csv      ← results so far (117 LLM pairs complete)
spsd_corpus_v3.csv       ← the 327 prompts
llm_v3_done.json         ← resume tracker (so LLM starts from pair 118)
```

### Pipeline scripts (download from this handoff package):
```
ale_prompt.py            ← required for LLM calls
run_llm_v3.py            ← Step 1: complete remaining 44 LLM pairs
score_and_judge_v3.py    ← Step 2: cosine similarity + LLM judge
hypothesis_v3.py         ← Step 3: all hypothesis tests + Excel report
```

### Accounts needed (both free):
- **Google Colab**: colab.research.google.com
- **Groq API key**: console.groq.com → sign up → create key

---

## One-Time Setup

### Install dependencies (run once, then restart):
```python
# Cell 1
!pip install -q groq sentence-transformers scipy openpyxl matplotlib
print("Done. Now: Runtime → Restart session.")
```
**Runtime → Restart session** after this finishes. Do not skip this.

### Add Groq API key:
Colab left sidebar → key icon (🔑) → Add new secret
- Name: `GROQ_API_KEY`
- Value: your key from console.groq.com

### Upload all files to /content/ via Files tab (left sidebar):
```
spsd_results_v3.csv
spsd_corpus_v3.csv
llm_v3_done.json
ale_prompt.py
run_llm_v3.py
score_and_judge_v3.py
hypothesis_v3.py
```

### Mount Google Drive (to save results safely):
```python
# Cell 2
from google.colab import drive
import shutil, os
drive.mount('/content/drive')
os.makedirs('/content/drive/MyDrive/spsd/v3_run', exist_ok=True)
print("Drive ready.")
```

---

## Step 1 — Complete LLM Calls (~8 min, 44 pairs remaining)

```python
# Cell 3
%run /content/run_llm_v3.py
```

**What you will see:**
```
Resuming: 117 pairs already done
Distilled rows: 161 | Remaining: 44
[118/161] P... save_in=+62t | raw_out=87t dist_out=72t
...
[161/161] P... 
LLM COMPLETE: 161 pairs
```

If it says `Remaining: 0` — all LLM pairs are already done, skip to Step 2.

**Save immediately:**
```python
# Cell 4
shutil.copy('/content/spsd_results_v3.csv',
            '/content/drive/MyDrive/spsd/v3_run/spsd_results_v3_afterLLM.csv')
print(f"Saved: {os.path.getsize('/content/spsd_results_v3.csv')//1024} KB")
```

---

## Step 2 — Cosine Similarity + LLM Judge (~3 min + ~25 min)

This step does two things automatically:
1. **Cosine similarity** (~3 min, no API needed) — measures how similar
   raw vs distilled responses are using a local embedding model
2. **LLM judge** (~25 min, uses Groq) — independently scores each pair
   on information equivalence (not which is better — whether they
   convey the same information to the user)

```python
# Cell 5
%run /content/score_and_judge_v3.py
```

**What you will see:**

First, similarity scoring:
```
Loading sentence-transformers/all-MiniLM-L6-v2 ...
Eligible pairs for quality scoring: 161
Cosine similarity — mean=0.XXXX >=0.70: XX/161
Similarity scores saved.
```

Then judge scoring:
```
Judge scoring: ~140 pairs (excluded ~18 misclassified)
  [  1/140] P002 raw=12 dist=11 equiv=4 ≈ close
  [  2/140] P003 raw=14 dist=13 equiv=5 ≡ equiv
  ...
```

**Judge output explained:**
- `raw=12` — judge scored raw response 12/15
- `dist=11` — judge scored distilled response 11/15
- `equiv=5` — responses are interchangeable (5=best, 1=completely different)
- `≡ equiv` — responses convey the same information to the user

**If you see rate limit messages:**
```
rate limit — waiting 90s...
```
This is normal — the script handles it automatically. Just wait.
If it happens repeatedly, edit `JUDGE_INTERVAL = 15.0` at the top
of `score_and_judge_v3.py` (default is 8.0) and restart the cell.

**Save immediately when done:**
```python
# Cell 6
for fname in ['spsd_results_v3.csv', 'judge_results_v3.json']:
    if os.path.exists(f'/content/{fname}'):
        shutil.copy(f'/content/{fname}',
                    f'/content/drive/MyDrive/spsd/v3_run/{fname}')
        size = os.path.getsize(f'/content/{fname}') // 1024
        print(f"Saved: {fname} ({size} KB)")
```

**If Colab disconnects mid-judge:**
The script is resume-safe. When you reconnect:
1. Restore `spsd_results_v3.csv` from Drive
2. If `judge_results_v3.json` exists on Drive, restore that too
3. Re-upload the scripts
4. Re-run Cell 5 — it will skip already-scored pairs automatically

---

## Step 3 — Hypothesis Tests + Excel Report (~2 min)

```python
# Cell 7
%run /content/hypothesis_v3.py
```

**Expected results (9 of 11 proven):**
```
H1  PRIMARY    Mean input token saving > 0           PROVEN ✓  p<0.001 d=1.22
H2  PRIMARY    Compression ratio < 1.0               PROVEN ✓  p<0.001 d=-3.26
H3  PRIMARY    100% distilled calls net positive     PROVEN ✓  161/161
H4  QUALITY    Mean cosine similarity > 0.70         NOT SIG   (corpus issue, see notes)
H5  QUALITY    LLM judge: equivalence > 4.0          PROVEN ✓  (if judge ran)
H6  SAFETY     Medical passthrough = 100%            PROVEN ✓  15/15
H7  SAFETY     Legal passthrough = 100%              PROVEN ✓  all detected
H8  EFFICIENCY verbose_social > general savings      PROVEN ✓  p<0.001 d=1.59
H9  EFFICIENCY Token saving varies by category       PROVEN ✓  p<0.001
H10 ECONOMY    Input saving > 10t gate threshold     PROVEN ✓  p<0.001
H11 ECONOMY    Cache + compression input saving      PENDING   (descriptive)
```

**Save everything:**
```python
# Cell 8
for fname in ['spsd_results_v3.csv', 'spsd_hypothesis_v3.xlsx',
              'judge_results_v3.json']:
    if os.path.exists(f'/content/{fname}'):
        shutil.copy(f'/content/{fname}',
                    f'/content/drive/MyDrive/spsd/v3_run/{fname}')
        size = os.path.getsize(f'/content/{fname}') // 1024
        print(f"Saved: {fname} ({size} KB)")
print("All done.")
```

---

## Notes on H4 and H5

**H4 (cosine similarity) shows NOT SIG** — about 24 rows in the corpus
are filter failures: bilingual prompts, jailbreaks, vocabulary exercises.
These produce very low similarity scores (mean 0.05-0.40) which drag
the overall mean below 0.70. Excluding these rows, mean similarity
= 0.7535, p<0.001 — PROVEN. This is documented in the paper.

**H5 (LLM judge)** — the judge uses `llama-3.3-70b-versatile` on Groq,
a different model from the eval model (`llama-3.1-8b-instant`), so
there is no contamination. It scores information equivalence (1-5),
not which response is "better". Score 5 = responses interchangeable.
Score 4 = same core information, minor detail differences.

---

## Time Estimates

| Step | Time |
|---|---|
| Step 1 — LLM calls (44 remaining) | ~8 min |
| Step 2 — Cosine similarity | ~3 min |
| Step 2 — LLM judge (~140 pairs at 8s) | ~20 min |
| Step 3 — Hypothesis + Excel | ~2 min |
| **Total** | **~35 min** |

---

## Troubleshooting

**"GROQ_API_KEY not found"**
Add it via Colab left sidebar → key icon → Secrets. Do not paste in code.

**"Resuming: 0 already done" (LLM starts from scratch)**
The `llm_v3_done.json` tracker is missing. Upload it from the data
files. If truly lost, the script will redo all 161 pairs (~27 min)
with the same results.

**"ModuleNotFoundError: groq"**
```python
!pip install -q groq
```
No restart needed for this one.

**"ModuleNotFoundError: sentence_transformers"**
```python
!pip install -q sentence-transformers
```

**Rate limits on judge (repeated 429 errors)**
Edit the top of `score_and_judge_v3.py`:
```python
JUDGE_INTERVAL = 15.0   # increase from 8.0
```

**Colab disconnects**
- LLM step: resume-safe, just re-run Cell 3
- Judge step: resume-safe, just re-run Cell 5
- Always restore files from Drive first (Cell 2 equivalent)

**"Nothing to judge — all pairs already done"**
All judge pairs are complete. Skip to Step 3.
