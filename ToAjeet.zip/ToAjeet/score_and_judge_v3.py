"""
SPSD v4.3 — Step 4: Quality Scoring + LLM-as-Judge
====================================================
Two independent quality signals for H4 and H5:

Method A — Cosine similarity (all-MiniLM-L6-v2, 22MB)
  Pair-wise embedding similarity between raw and distilled responses.
  Threshold: 0.70 (established from pilot testing).

Method B — LLM-as-judge (llama-3.3-70b-versatile on Groq)
  DIFFERENT model from evaluation model (no contamination).
  Blind A/B: judge does not know which response is raw or distilled.
  Scores each on: accuracy (1-5), completeness (1-5), tone (1-5), quality (1-5)
  Gives a winner verdict and one-sentence reasoning.
  Rate: 8s between judge calls.

Input:  /content/spsd_results_v3.csv  (updated in place)
Output: /content/judge_results_v3.json
Run:    %run score_and_judge_v3.py
"""
import csv, json, os, time, sys, random, re
sys.path.insert(0, '/content')
try:
    from prompt_flags import detect_lang_flag, detect_content_flag
except ImportError:
    def detect_lang_flag(t): return 'EN'
    def detect_content_flag(t): return 'OK'
import numpy as np

# ── Cosine similarity ─────────────────────────────────────────────────────────
print("Loading sentence-transformers/all-MiniLM-L6-v2 ...")
from sentence_transformers import SentenceTransformer
st_model = SentenceTransformer('sentence-transformers/all-MiniLM-L6-v2')
print("Loaded.")

INPUT_FILE  = "/content/spsd_results_v3.csv"
JUDGE_FILE  = "/content/judge_results_v3.json"
SIM_THRESH  = 0.70

with open(INPUT_FILE, newline='', encoding='utf-8') as f:
    rows = list(csv.DictReader(f))
by_id = {r['id']: r for r in rows}

def sf(v):
    try: return float(v)
    except: return None

# Eligible: distilled, both responses present, no error
paired = [r for r in rows
          if r['passthrough']=='False'
          and r.get('raw_response','').strip()
          and r.get('dist_response','').strip()
          and not r.get('raw_response','').startswith('ERROR')
          and not r.get('dist_response','').startswith('ERROR')]

print(f"\nEligible pairs for quality scoring: {len(paired)}")

# ── Cosine similarity scoring ─────────────────────────────────────────────────
if paired:
    raw_texts  = [r['raw_response'][:600]  for r in paired]
    dist_texts = [r['dist_response'][:600] for r in paired]
    raw_embs   = st_model.encode(raw_texts,  convert_to_numpy=True,
                                  show_progress_bar=True, batch_size=64)
    dist_embs  = st_model.encode(dist_texts, convert_to_numpy=True,
                                  show_progress_bar=True, batch_size=64)
    for row, re_, de in zip(paired, raw_embs, dist_embs):
        sim  = float(np.dot(re_,de) / (np.linalg.norm(re_)*np.linalg.norm(de)))
        flag = 'OK' if sim >= SIM_THRESH else ('BORDERLINE' if sim >= 0.50 else 'LOW')
        by_id[row['id']]['semantic_similarity'] = f"{sim:.4f}"
        by_id[row['id']]['quality_flag']        = flag
    sims = np.array([float(by_id[r['id']]['semantic_similarity']) for r in paired])
    print(f"Cosine similarity — mean={np.mean(sims):.4f} "
          f">=0.70: {sum(sims>=SIM_THRESH)}/{len(sims)}")

# Save after similarity scoring
updated = list(by_id.values())
ak = list(dict.fromkeys(k for r in updated for k in r.keys()))
with open(INPUT_FILE,'w',newline='',encoding='utf-8') as f:
    w = csv.DictWriter(f,fieldnames=ak,quoting=csv.QUOTE_ALL,
                       extrasaction='ignore',restval='')
    w.writeheader(); w.writerows(updated)
print("Similarity scores saved.")

# ── SIMILARITY COMPLETE ───────────────────────────────────────────────────────
print()
print("="*60)
print("SIMILARITY SCORING COMPLETE")
print("="*60)
sims_done = [r for r in rows if r.get('semantic_similarity','').strip()]
sim_vals  = [float(r['semantic_similarity']) for r in sims_done
             if r.get('semantic_similarity','').strip()]
print(f"Pairs scored: {len(sim_vals)}")
if sim_vals:
    import numpy as _np
    print(f"Mean sim:     {_np.mean(sim_vals):.4f}")
    print(f">=0.70:       {sum(1 for s in sim_vals if s>=0.70)}/{len(sim_vals)}")
print()
print("spsd_results_v3.csv updated with semantic_similarity column.")
print("SAVE TO DRIVE NOW before judge starts:")
print()
print("  from google.colab import drive")
print("  import shutil")
print("  drive.mount('/content/drive')")
print("  shutil.copy('/content/spsd_results_v3.csv',")
print("              '/content/drive/MyDrive/spsd/v3_run/spsd_results_v3_afterSIM.csv')")
print()
print("Starting judge in 15 seconds... (interrupt now to save first)")
print("="*60)

import time as _time
for _i in range(15, 0, -1):
    print(f"  Starting judge in {_i}s... (Ctrl+C / interrupt to pause)", end='
', flush=True)
    _time.sleep(1)
print()
print("Starting judge now...")
print()

# ── LLM-as-judge ─────────────────────────────────────────────────────────────
try:
    from google.colab import userdata
    GROQ_KEY = userdata.get("GROQ_API_KEY")
except Exception:
    GROQ_KEY = os.environ.get("GROQ_API_KEY","")

if not GROQ_KEY:
    print("\nNo GROQ_API_KEY — skipping LLM judge. Re-run after adding key.")
else:
    from groq import Groq
    judge_client = Groq(api_key=GROQ_KEY)
    JUDGE_MODEL    = "llama-3.3-70b-versatile"   # distinct from eval model
    JUDGE_INTERVAL = 8.0
    RETRY_WAIT     = 90

    JUDGE_SYSTEM = (
        "You are evaluating whether two AI responses convey equivalent information to a user query.\n\n"
        "You will receive:\n"
        "  ORIGINAL QUERY: the user's question or request\n"
        "  RESPONSE A: one AI response\n"
        "  RESPONSE B: another AI response\n\n"
        "Your task is to assess information equivalence — not which response is better,\n"
        "but whether both responses would leave the user equally informed.\n\n"
        "Score EACH response independently on:\n"
        "  intent_coverage (1-5): Does this response address what the user actually asked?\n"
        "    5=fully addresses all parts  1=misses the main point entirely\n\n"
        "  factual_quality (1-5): Are the facts, recommendations, or answers correct and useful?\n"
        "    5=accurate, specific, actionable  1=vague, incorrect, or unhelpful\n\n"
        "  information_completeness (1-5): Does this response contain the key information needed?\n"
        "    5=everything the user needs  1=missing critical information\n\n"
        "Then assess EQUIVALENCE between the two responses:\n"
        "  equivalence (1-5): How interchangeable are these two responses?\n"
        "    5=user receiving either response would be equally informed and able to act\n"
        "    4=minor differences in detail, same core information\n"
        "    3=one response has noticeably more/different useful information\n"
        "    2=significant information gap between responses\n"
        "    1=responses give substantially different information or one fails completely\n\n"
        "Respond ONLY with valid JSON, no other text:\n"
        '{"response_a":{"intent_coverage":N,"factual_quality":N,"information_completeness":N,"total":N},'
        ' "response_b":{"intent_coverage":N,"factual_quality":N,"information_completeness":N,"total":N},'
        ' "equivalence":N,'
        ' "what_differs":"one sentence on key difference, or responses are equivalent"}'
    )

    judge_results = {}
    if os.path.exists(JUDGE_FILE):
        with open(JUDGE_FILE) as f: judge_results = json.load(f)
        print(f"\nJudge: resuming ({len(judge_results)} already scored)")

    # Pre-specified exclusion criterion (same as hypothesis tests):
    # 1. sim < 0.40 in general_conversational or multi_intent_linked
    # 2. Coding/technical task prompts misclassified as verbose_social
    import re as _re
    _TASK_REQ = _re.compile(
        r'\b(provide (a |the )?code|'
         r'can you (code|write (a |the )?(code|function|script|program|tool|system|app))|'
         r'write (the |a )?(code|function|script|program|tool|system|app|algorithm|query|class)|'
         r'code (in|for|using) [a-z#+]+|'
         r'in (python|java|c#|c\+\+|javascript|typescript|sql|matlab|php|ruby|swift)|'
         r'using (python|java|c#|c\+\+|javascript|typescript|sql|matlab)|'
         r'calculate (the |a )?(unit cost|total cost|profit|revenue|discount|interest|tax)|'
         r'take\.?off (sheet|list|document)|bill of materials|'
         r'build (a |the )?(tool|system|app|application|database|model)|'
         r'develop (a |the )?(tool|system|app|application|model)|'
         r'implement (a |the )?)\b', _re.I)

    EXCL_CATS = {'general_conversational','multi_intent_linked'}
    excl_ids = (
        # low-sim misclassified (general/multi-intent prompts with poor compression)
        {r['id'] for r in paired
         if r['category'] in EXCL_CATS
         and sf(by_id[r['id']].get('semantic_similarity')) is not None
         and (sf(by_id[r['id']].get('semantic_similarity')) or 1) < 0.40}
        |
        # coding/technical tasks misclassified as verbose_social
        {r['id'] for r in paired
         if r['category'] == 'verbose_social'
         and _TASK_REQ.search(r.get('raw_prompt',''))}
    )

    coding_excl = {r['id'] for r in paired
                   if r['category'] == 'verbose_social'
                   and _TASK_REQ.search(r.get('raw_prompt',''))}
    if coding_excl:
        print(f"Coding prompts misclassified as verbose_social (excluded from judge): "
              f"{sorted(coding_excl)}")

    to_judge = [r for r in paired
                if r['id'] not in judge_results and r['id'] not in excl_ids]
    print(f"Judge scoring: {len(to_judge)} pairs "
          f"(excluded {len(excl_ids)}: {len(coding_excl)} coding-misclassified, "
          f"{len(excl_ids)-len(coding_excl)} low-sim)")

    random.seed(42)
    for i, row in enumerate(to_judge):
        pid     = row['id']
        orig    = row['raw_prompt']
        raw_r   = row['raw_response']
        dist_r  = row['dist_response']

        # Random A/B — record assignment
        if random.random() > 0.5:
            resp_a, resp_b, a_is = raw_r, dist_r, 'raw'
        else:
            resp_a, resp_b, a_is = dist_r, raw_r, 'dist'

        prompt = (f"ORIGINAL QUERY:\n{orig}\n\n---\n\n"
                  f"RESPONSE A:\n{resp_a}\n\n---\n\n"
                  f"RESPONSE B:\n{resp_b}")

        for attempt in range(4):
            try:
                resp = judge_client.chat.completions.create(
                    model=JUDGE_MODEL,
                    messages=[{"role":"system","content":JUDGE_SYSTEM},
                               {"role":"user","content":prompt}],
                    max_tokens=150, temperature=0.1)
                raw_json = resp.choices[0].message.content or ""
                clean_j  = re.sub(r'^```[a-z]*\n?','',raw_json.strip())
                clean_j  = re.sub(r'\n?```$','',clean_j)
                parsed   = json.loads(clean_j)

                sa          = parsed['response_a']['total']
                sb          = parsed['response_b']['total']
                equivalence = int(parsed.get('equivalence', 3))
                what_differs= parsed.get('what_differs', '')

                if a_is == 'raw':
                    raw_s=sa; dist_s=sb
                else:
                    raw_s=sb; dist_s=sa

                judge_results[pid] = {
                    'raw_score':   raw_s,
                    'dist_score':  dist_s,
                    'equivalence': equivalence,
                    'what_differs':what_differs,
                    'a_is':        a_is,
                    'raw_detail':  parsed['response_a'] if a_is=='raw' else parsed['response_b'],
                    'dist_detail': parsed['response_b'] if a_is=='raw' else parsed['response_a'],
                }
                by_id[pid].update({
                    'judge_raw_score':   str(raw_s),
                    'judge_dist_score':  str(dist_s),
                    'judge_equivalence': str(equivalence),
                    'judge_what_differs':what_differs[:200],
                })
                eq_sym = {5:'≡ equiv', 4:'≈ close', 3:'~ diff', 2:'≠ gap', 1:'✗ fail'}
                print(f"  [{i+1:3d}/{len(to_judge)}] {pid} "
                      f"raw={raw_s:2d} dist={dist_s:2d} "
                      f"equiv={equivalence} {eq_sym.get(equivalence,'')}")
                break
            except Exception as e:
                if "429" in str(e) or "rate" in str(e).lower():
                    wait = RETRY_WAIT*(attempt+1)
                    print(f"  rate limit — waiting {wait}s..."); time.sleep(wait)
                elif attempt == 3:
                    print(f"  [{pid}] judge error: {e}")
                else:
                    time.sleep(5)
        time.sleep(JUDGE_INTERVAL)

        if (i+1) % 10 == 0:
            with open(JUDGE_FILE,'w') as f: json.dump(judge_results,f,indent=2)
            updated = list(by_id.values())
            ak = list(dict.fromkeys(k for r in updated for k in r.keys()))
            with open(INPUT_FILE,'w',newline='',encoding='utf-8') as f:
                w = csv.DictWriter(f,fieldnames=ak,quoting=csv.QUOTE_ALL,
                                   extrasaction='ignore',restval='')
                w.writeheader(); w.writerows(updated)
            print(f"  ── checkpoint ({i+1} judged) ──")

    with open(JUDGE_FILE,'w') as f: json.dump(judge_results,f,indent=2)
    from collections import Counter
    wins = Counter(v['winner'] for v in judge_results.values())
    jrs  = [v['raw_score']  for v in judge_results.values()]
    jds  = [v['dist_score'] for v in judge_results.values()]
    print(f"\nJudge summary ({len(judge_results)} pairs, model={JUDGE_MODEL}):")
    print(f"  dist wins={wins['dist']}  raw wins={wins['raw']}  ties={wins['tie']}")
    print(f"  mean raw score  = {np.mean(jrs):.2f}")
    print(f"  mean dist score = {np.mean(jds):.2f}")

# Final CSV save
updated = list(by_id.values())
ak = list(dict.fromkeys(k for r in updated for k in r.keys()))
with open(INPUT_FILE,'w',newline='',encoding='utf-8') as f:
    w = csv.DictWriter(f,fieldnames=ak,quoting=csv.QUOTE_ALL,
                       extrasaction='ignore',restval='')
    w.writeheader(); w.writerows(updated)
print(f"\nAll scores saved to {INPUT_FILE}")
print(f"Next: %run hypothesis_v3.py")
